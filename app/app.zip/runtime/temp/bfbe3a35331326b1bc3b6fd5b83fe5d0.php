<?php /*a:1:{s:68:"D:\phpstudy_pro\WWW\dockerthinkphp6.cc\tp\view\fileguanli\index.html";i:1736845582;}*/ ?>
<!doctype html>
<html lang="zh-CN" data-bs-theme="dark">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Bootstrap demo</title>
  <link rel="stylesheet"  href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" >
          <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/editor.md@1.5.0/css/editormd.css" />

  <link href="/static/css/jquery.bsPhotoGallery.css" rel="stylesheet">
 	 <style>
.card img{
    height: 200px;
    object-fit: cover;
}

        </style>
      <style>
        /* 设置覆盖其他元素的div样式 */
        .cover {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            display:none;
            background-color: rgba(16, 17, 20, 0.5); /* 设置背景颜色并添加透明度 */
            z-index: 999; /* 设置较高的层级，使其在其他元素之上 */
        }
    </style>
</head>
<body>

  <ul class="nav nav-tabs" id="myTab" role="tablist">
    <li class="nav-item" role="presentation">
      <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">我的文章</button>
    </li>
    <li class="nav-item" role="presentation">
      <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">新建文章</button>
    </li>
    <li class="nav-item" role="presentation">
      <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact" type="button" role="tab" aria-controls="contact" aria-selected="false">图床图片列表</button>
    </li>
     <li class="nav-item" role="presentation">
      <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#delcontact" type="button" role="tab" aria-controls="contact" aria-selected="false">文章回收站</button>
    </li>
      <li class="nav-item" role="presentation">
      <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#delcache" type="button" role="tab" aria-controls="contact" aria-selected="false">删除缓存</button>
    </li>
  </ul>
  <div class="container">
    <div class="tab-content" id="myTabContent">
      <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">

       <table class="table  table-striped" id="articleList">
        <tr><td>ID</td><td>标题</td><td>创建日期</td></tr>
      </table>
      <input type="hidden"  name="page" id="page" value='1'>
      <a id="loadmore" class="btn btn-primary">加载更多...</a>
    
    </div>
    <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
      <div class="container">
        <h3 id="labelNew">新增<span style="color: red;">*</span></h3> <div class="text-center" style="max-width:200px;max-height:100px;"> </div>


            <form   id="addNewForm">
         <div class="row">
           <div class="form-group" style="width: 98%">
            <input type="hidden" class="form-control" name="id" id="id" >

            <input type="text" class="form-control" name="title" id="title" placeholder="标题" style="width: 100%;" required="true">
          </div>
        </div>
        <div class="row  align-items-center">
          <div class="col">
            <div class="col-auto">
              <label for="inputPassword6" class="col-form-label">特色图片</label>
            </div>
            <div class="col-auto">
             <input type="url" class="form-control" style="width: 400px;"  name="img" id="img" placeholder="" >
           </div>
           <div class="row g-3 align-items-center">
            <div class="col-auto">
             <label for="exampleInputEmail2">分类<span style="color: red;">*</span></label>
           </div>
           <div class="col-auto">
            <select class="form-select" name="category[]" id="category"  aria-label=" select example" >
            </select> 
          </div>
          <div class="col-auto">
           <label for="exampleInputEmail2">标签</label></div>
           <div class="col-auto">
            <input type="text" class="form-control" name="tags" id="tags" placeholder="标签1,标签2" value ="AI绘画,国漫">
          </div>
        </div>
      </div>

      <div class="col col-lg-6">
       <img src="https://cloudflare-imgbed-5ni.pages.dev/file/1735126196243_2424442d-2.png" class ="imgall" style="width: 200px;height: 100px;object-fit: cover;" alt="...">
       <div class="editormd-file-input "><input type="file" id="file" name="editormd-image-file" ><input type="submit"  value="本地上传"></div>
     </div>
     

     
   </div>


   <a  tabindex="0"  role="button"  type="submit" id="btn_saveAddNew" class="btn btn-primary" onclick="saveAddNew()">保存</a>
 

   <div id="content"><textarea style="display:none;"></textarea></div>
 </form>
  </div>
  
</div>
<div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
<!-- dfdf-->
<div class="row" id ="imginfo">

</div>
<!-- end-->
<input type="hidden"  name="page" id="imgpage" value='1'>
<a id="imgloadmore" class="btn btn-primary">加载更多...</a>
</div>
<!-- str-->
  <div class="tab-pane fade" id="delcontact" role="tabpanel" aria-labelledby="profile-tab">
       <table class="table  table-striped" id="articleListdel">
        <tr><td>ID</td><td>标题</td><td>创建日期</td></tr>
      </table>
      <input class="form-control" name="page" id="delpage" value='1'>
      <a id="loadmoredel" class="btn btn-primary">加载删除文章...</a>
    </div>

<!-- end-->
<!-- str-->
  <div class="tab-pane fade" id="delcache" role="tabpanel" aria-labelledby="profile-tab">
      <div class="mb-3">
  <label for="exampleFormControlTextarea1" class="form-label">删除链接 一行一个</label>
  <textarea class="form-control" id="delurls"></textarea>
  <label for="exampleFormControlTextarea1" class="form-label">  <a id="delcahe" class="btn btn-primary">删除</a></label>

</div>

    </div>

<!-- end-->
</div>
</div>
 <script src="https://cdn.staticfile.org/jquery/2.2.4/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.0.0/crypto-js.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
          <script src="https://cdn.jsdelivr.net/npm/editor.md@1.5.0/editormd.js"></script> 
        
<script src="https://lf3-cdn-tos.bytecdntp.com/cdn/expire-1-M/clipboard.js/2.0.10/clipboard.min.js"></script>
<!--   <script src="/static/js/pasteUploadImg.js" type="text/javascript"></script> -->
<script type="text/javascript">
  let params ='${props.OPT.admin_tags}'
  function uusfsw(params){
    let arr = params.split(",");
    const result = [];
    for (let i = 0; i < arr.length; i++) {
      if (arr[i]) {
        result.push(arr[i]);
      }
    }
    return result;
  }
  console.log(uusfsw(params));
  let tasgdasd=uusfsw(params);
$(function() {
 
            //获取分类

            var categoryJson =tasgdasd;
            //获取菜单
            var menuJson = [];
            var linkJson = [];
            var mdEditor = editormd("content", {
                    // width  : "90%",
                    height : 640,
                    path   : "https://cdn.jsdelivr.net/npm/editor.md@1.5.0/lib/",
                    appendMarkdown : "# MarkDown", 
                    saveHTMLToTextarea : true,
                    theme: "dark",
                     editorTheme: "pastel-on-dark", // 编辑器主题  
                     previewTheme: "dark", // 预览主题
                     imageUpload    : true,
    imageFormats   : ["jpg", "jpeg", "gif", "png", "bmp", "webp"],
    imageUploadURL : "/${props.OPT.admin}/boot/upload",
    onload : function() {
                            initPasteDragImg(this); //必须
                        },

                    mode : "markdown",
                    tex  : true,
                    tocm : true, 
                    codeFold : true
                });
       
            var category = $('#category');
            category.empty();
            for (var i = 0; i < categoryJson.length; i++) {
                category.append('<option id=' + categoryJson[i] + ' value=' + categoryJson[i] + '>' + categoryJson[i] + '</option>');
            }
            $("#loadmore").click();//初始加载一页
           // $("#imgloadmore").click();//初始加载一页
             //$("#loadmoredel").click();//初始加载一页


  })
        //加载文章列表  
        $("#loadmore").click(function(){
          var page=$("#page").val();
          $.ajax({
            url:"/Fileguanli/getList?fl=<?php echo $fl; ?>",
            type:'GET',
            dataType:"json",
                //data:{"page":page,"typeid":typeid},
                success:function(data){

                  tableContent="";
                  $.each(data,function(i){
                    var Info = data[i];
                    var num = i+1;
                    tableContent += '<tr><td>'+i+'</td><td><a href="/Fileguanli?fl='+Info.id+'">'+Info.title+'</a></td><td>'+'<a href="/Fileguanli/edit?fl='+Info.id+'">下载</a>'+'</td></tr>';

                  })
                  $("#articleList").append(tableContent);
                  $("#page").val(++page);

                }
              });
        })


            ///////////////////////////////////////strr






            ////////////////////end 
   
   

      </script>
<script>
var clipboard = new ClipboardJS('.card-body a');

clipboard.on('success', function(e) {
    console.info('Action:', e.action);
    console.info('Text:', e.text);
    console.info('Trigger:', e.trigger);
   alert(e.text);
    e.clearSelection();
});

clipboard.on('error', function(e) {
    console.error('Action:', e.action);
    console.error('Trigger:', e.trigger);
    alert("复制  失败");
});
</script>
<script type="text/javascript">
function initPasteDragImg(Editor) {
    var doc = document.getElementById(Editor.id);
    const fileInput = document.getElementById('file');
    fileInput.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        console.log(file);
        let md5 = '';
        md5 = await calculateMD5(file);
        console.log(md5);
         uploadImg(file, Editor, md5 = '', '')
  
    })


    doc.addEventListener('paste', async function (event) {
        var items = (event.clipboardData || window.clipboardData).items;
        var file = null;
        if (items && items.length) {
            // 搜索剪切板items
            for (var i = 0; i < items.length; i++) {
                if (items[i].type.indexOf('image') !== -1) {
                    file = items[i].getAsFile();
                    break;
                }
            }
        } else {
            console.log("当前浏览器不支持");
            return;
        }
        if (!file) {
            console.log("粘贴内容非图片");
            return;
        }

        var md51 = await calculateMD5(file);
        console.log(md51);
        uppseee(file, Editor, md51);
    });

    var dashboard = document.getElementById(Editor.id)
    dashboard.addEventListener("dragover", function (e) {
        e.preventDefault()
        e.stopPropagation()
    })
    dashboard.addEventListener("dragenter", function (e) {
        e.preventDefault()
        e.stopPropagation()
    })
    dashboard.addEventListener("drop", async function (e) {
        e.preventDefault()
        e.stopPropagation()
        var files = this.files || e.dataTransfer.files;
        //uppseee(files[0],Editor)
        var md51 = await calculateMD5(files[0]);
        console.log(md51);
        uppseee(files[0], Editor, md51);
        //compressAndUpload(files[0]);

    })
}
function uppseee(file, Editor, md5 = '') {
    //const canvas = document.getElementById('canvas');
    var canvas = document.createElement('canvas'); // 创建canvas
    let fileName = file.name;
    const ctx = canvas.getContext('2d');
    const MAXWIDTH = 1920;
    const MAXHEIGHT = 1920;
    const reader = new FileReader();
    const img = new Image();

    reader.onload = function (event) {
        img.src = event.target.result;
        img.onload = () => {
            let targetW = img.width;
            let targetH = img.height;

            console.log('targetW ' + targetW)
            if (img.width > MAXWIDTH || img.height > MAXHEIGHT) {
                if (img.width / img.height > MAXWIDTH / MAXHEIGHT) {
                    targetW = MAXWIDTH;
                    targetH = Math.round(MAXWIDTH * (img.height / img.width));
                } else {
                    targetH = MAXHEIGHT;
                    targetW = Math.round(MAXHEIGHT * (img.width / img.height));
                }
            }

            canvas.width = targetW;
            canvas.height = targetH;
            console.log('canvas.width ' + canvas.width)
            ctx.clearRect(0, 0, targetW, targetH);
            ctx.drawImage(img, 0, 0, targetW, targetH);

            canvas.toBlob((blob) => {
                // 上传 Blob 对象到服务器
                // uploadBlob(blob);
                uploadImg(blob, Editor, md5, fileName);

            }, 'image/webp', 0.95);
        };



    }
    reader.readAsDataURL(file); // 读取文件

}

// function compressAndUpload(file) {
//     var reader = new FileReader(); // 创建FileReader对象

//     reader.onload = function(event) {
//         var img = new Image(); // 创建Image对象
//         img.src = event.target.result; // 设置图片源为文件内容

//         img.onload = function() {
//             var canvas = document.createElement('canvas'); // 创建canvas
//             var ctx = canvas.getContext('2d');
//             canvas.width = 122; // 将宽度缩小为原来的50%
//             canvas.height = 122; // 将高度缩小为原来的50%
//             ctx.drawImage(img, 0, 0, canvas.width, canvas.height); // 将图片绘制到canvas
//             canvas.toBlob(function(blob) {
//                 uploadImg(blob,Editor);
//                // uploadImage(blob); // 上传压缩后的图片
//             }, 'image/webp', 0.8); // 将canvas内容转换为Blob，设置JPEG质量为0.7
//         }
//     }
//     reader.readAsDataURL(file); // 读取文件
// }

function uploadImg(file1, Editor, md5 = '', fileName) {
    $(".cover").attr("style","display:block;");
    var formData = new FormData();
    //var fileName=new Date().getTime()+".webp";
    fileName = file1.name;
     formData.append('file', file1, fileName);
    formData.append('md5', md5);
    formData.append('fl', '<?php echo htmlentities((string) $fl); ?>');
    $.ajax({
        url: '/Fileguanli/upload',
        type: 'post',
        data: formData,
        processData: false,
        contentType: false,
        dataType: 'json',
        success: function (msg) {
            var success = msg['success'];
            if (success == 1) {
                    alert("图片上传成功");
                     $(".cover").attr("style","display:none;");
            } else {
                console.log(msg);
                alert("上传失败");
                $(".cover").attr("style","display:none;");
            }
        }
    });
}


function readFile(file) {

    return new Promise((resolve, reject) => {


        const reader = new FileReader();


        reader.onload = () => resolve(reader.result);


        reader.onerror = reject;


        reader.readAsArrayBuffer(file);


    });


}

async function calculateMD5(file) {

    const content = await readFile(file);


    const wordArray = CryptoJS.lib.WordArray.create(content);


    const md5 = CryptoJS.MD5(wordArray).toString();


    return md5;


}

</script>
<div class ="cover"></div>
    </body>
    </html>`