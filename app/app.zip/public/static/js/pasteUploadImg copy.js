function initPasteDragImg(Editor) {
    var doc = document.getElementById(Editor.id);
    const fileInput = document.getElementById('file');
    fileInput.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        console.log(file);
        let md5 = '';
        md5 = await calculateMD5(file);
        console.log(md5);
        uppseee(file, Editor, md5);
    })


    doc.addEventListener('paste', async function (event) {
        var items = (event.clipboardData || window.clipboardData).items;
        var file = null;
        if (items && items.length) {
            // 搜索剪切板items
            for (var i = 0; i < items.length; i++) {
                if (items[i].type.indexOf('image') !== -1) {
                    file = items[i].getAsFile();
                    break;
                }
            }
        } else {
            console.log("当前浏览器不支持");
            return;
        }
        if (!file) {
            console.log("粘贴内容非图片");
            return;
        }

        var md51 = await calculateMD5(file);
        console.log(md51);
        uppseee(file, Editor, md51);
    });

    var dashboard = document.getElementById(Editor.id)
    dashboard.addEventListener("dragover", function (e) {
        e.preventDefault()
        e.stopPropagation()
    })
    dashboard.addEventListener("dragenter", function (e) {
        e.preventDefault()
        e.stopPropagation()
    })
    dashboard.addEventListener("drop", async function (e) {
        e.preventDefault()
        e.stopPropagation()
        var files = this.files || e.dataTransfer.files;
        //uppseee(files[0],Editor)
        var md51 = await calculateMD5(files[0]);
        console.log(md51);
        uppseee(files[0], Editor, md51);
        //compressAndUpload(files[0]);

    })
}
function uppseee(file, Editor, md5 = '') {
    //const canvas = document.getElementById('canvas');
    var canvas = document.createElement('canvas'); // 创建canvas
    let fileName = file.name;
    const ctx = canvas.getContext('2d');
    const MAXWIDTH = 1920;
    const MAXHEIGHT = 1920;
    const reader = new FileReader();
    const img = new Image();

    reader.onload = function (event) {
        img.src = event.target.result;
        img.onload = () => {
            let targetW = img.width;
            let targetH = img.height;

            console.log('targetW ' + targetW)
            if (img.width > MAXWIDTH || img.height > MAXHEIGHT) {
                if (img.width / img.height > MAXWIDTH / MAXHEIGHT) {
                    targetW = MAXWIDTH;
                    targetH = Math.round(MAXWIDTH * (img.height / img.width));
                } else {
                    targetH = MAXHEIGHT;
                    targetW = Math.round(MAXHEIGHT * (img.width / img.height));
                }
            }

            canvas.width = targetW;
            canvas.height = targetH;
            console.log('canvas.width ' + canvas.width)
            ctx.clearRect(0, 0, targetW, targetH);
            ctx.drawImage(img, 0, 0, targetW, targetH);

            canvas.toBlob((blob) => {
                // 上传 Blob 对象到服务器
                // uploadBlob(blob);
                uploadImg(blob, Editor, md5, fileName);

            }, 'image/webp', 0.95);
        };



    }
    reader.readAsDataURL(file); // 读取文件

}

// function compressAndUpload(file) {
//     var reader = new FileReader(); // 创建FileReader对象

//     reader.onload = function(event) {
//         var img = new Image(); // 创建Image对象
//         img.src = event.target.result; // 设置图片源为文件内容

//         img.onload = function() {
//             var canvas = document.createElement('canvas'); // 创建canvas
//             var ctx = canvas.getContext('2d');
//             canvas.width = 122; // 将宽度缩小为原来的50%
//             canvas.height = 122; // 将高度缩小为原来的50%
//             ctx.drawImage(img, 0, 0, canvas.width, canvas.height); // 将图片绘制到canvas
//             canvas.toBlob(function(blob) {
//                 uploadImg(blob,Editor);
//                // uploadImage(blob); // 上传压缩后的图片
//             }, 'image/webp', 0.8); // 将canvas内容转换为Blob，设置JPEG质量为0.7
//         }
//     }
//     reader.readAsDataURL(file); // 读取文件
// }

function uploadImg(file1, Editor, md5 = '', fileName) {
    $(".cover").attr("style","display:block;");
    var formData = new FormData();
    //var fileName=new Date().getTime()+".webp";
    fileName = fileName + ".webp";
    let person = prompt("输入文件名");
    if (person!=null && person!=""){ 
        fileName =person+ ".webp";
       } 
    ;
    formData.append('editormd-image-file', file1, fileName);
    formData.append('md5', md5);
    $.ajax({
        url: Editor.settings.imageUploadURL,
        type: 'post',
        data: formData,
        processData: false,
        contentType: false,
        dataType: 'json',
        success: function (msg) {
            var success = msg['success'];
            if (success == 1) {
                var url = msg["url"];
                if (/\.(png|jpg|jpeg|gif|bmp|ico|webp)$/.test(url)) {
                    $("#img").attr("value", msg["url"]);
                    $(".imgall").attr("src", msg["url"]);
                    var insertHtml = '<div class="card" style="width: 18rem;">' +
                        '<img src="' + msg["url"] + '" class="img-responsive center-block" alt="...">' +
                        '<div class="card-body">' +
                        '<a href="#" class="btn btn-primary" id ="copyimgurl" data-clipboard-text="' + msg["url"] + '">图片链接</a>' +
                        `<a href="#" class="btn btn-primary" id ="copyimgurl" style="float:right;"  data-clipboard-text="![` + msg["title"] + `](` + msg["url"] + ` '` + msg["title"] + `')"> Markdown</a>` +
                        "</div></div>";
                    $('#imginfo').find('div').eq(0).before(insertHtml);
                    if ($('#title').val() == "" || $('#title').val() == null) {
                        Editor.insertValue("![" + msg["title"] + "](" + msg["url"] + " '" + msg["title"] + "')");
                    } else {
                        var tltl = $('#title').val()
                        console.log(tltl)
                        Editor.insertValue("![" + tltl + "](" + msg["url"] + " '" + tltl + "')");
                    }

                    alert("图片上传成功");
                    $(".cover").attr("style","display:none;");
                } else {
                    Editor.insertValue("[下载附件](" + msg["url"] + ")");
                    $(".cover").attr("style","display:none;");
                }
            } else {
                console.log(msg);
                alert("上传失败");
                $(".cover").attr("style","display:none;");
            }
        }
    });
}


function readFile(file) {

    return new Promise((resolve, reject) => {


        const reader = new FileReader();


        reader.onload = () => resolve(reader.result);


        reader.onerror = reject;


        reader.readAsArrayBuffer(file);


    });


}

async function calculateMD5(file) {

    const content = await readFile(file);


    const wordArray = CryptoJS.lib.WordArray.create(content);


    const md5 = CryptoJS.MD5(wordArray).toString();


    return md5;


}