
(() => {
  
    const saveToLocal = {
        set: (key, value, ttl) => {
            if (!ttl) return
            const expiry = Date.now() + ttl * 86400000
            localStorage.setItem(key, JSON.stringify({
                value,
                expiry
            }))
        },
        get: key => {
            const itemStr = localStorage.getItem(key)
            if (!itemStr) return undefined
            const {
                value,
                expiry
            } = JSON.parse(itemStr)
            if (Date.now() > expiry) {
                localStorage.removeItem(key)
                return undefined
            }
            return value
        }
    };
  
    window.btf = {
        saveToLocal,
        getScript: (url, attr = {}) => new Promise((resolve, reject) => {
            const script = document.createElement('script')
            script.src = url
            script.async = true
            Object.entries(attr).forEach(([key, val]) => script.setAttribute(key, val))
            script.onload = script.onreadystatechange = () => {
                if (!script.readyState || /loaded|complete/.test(script.readyState)) resolve()
            }
            script.onerror = reject
            document.head.appendChild(script)
        }),
        getCSS: (url, id) => new Promise((resolve, reject) => {
            const link = document.createElement('link')
            link.rel = 'stylesheet'
            link.href = url
            if (id) link.id = id
            link.onload = link.onreadystatechange = () => {
                if (!link.readyState || /loaded|complete/.test(link.readyState)) resolve()
            }
            link.onerror = reject
            document.head.appendChild(link)
        }),
        addGlobalFn: (key, fn, name = false, parent = window) => {
            if (!false && key.startsWith('pjax')) return
            const globalFn = parent.globalFn || {}
            globalFn[key] = globalFn[key] || {}
            globalFn[key][name || Object.keys(globalFn[key]).length] = fn
            parent.globalFn = globalFn
        }
    }
  
  
    const activateDarkMode = () => {
        document.documentElement.setAttribute('data-theme', 'dark')
        if (document.querySelector('meta[name="theme-color"]') !== null) {
            document.querySelector('meta[name="theme-color"]').setAttribute('content', '#0d0d0d')
        }
    }
    const activateLightMode = () => {
        document.documentElement.setAttribute('data-theme', 'light')
        if (document.querySelector('meta[name="theme-color"]') !== null) {
            document.querySelector('meta[name="theme-color"]').setAttribute('content', '#ffffff')
        }
    }
  
    btf.activateDarkMode = activateDarkMode
    btf.activateLightMode = activateLightMode
  
    const theme = saveToLocal.get('theme')
  
    activateDarkMode();
  
  
    const asideStatus = saveToLocal.get('aside-status')
    if (asideStatus !== undefined) {
        document.documentElement.classList.toggle('hide-aside', asideStatus === 'hide')
    }
  
  
    const detectApple = () => {
        if (/iPad|iPhone|iPod|Macintosh/.test(navigator.userAgent)) {
            document.documentElement.classList.add('apple')
        }
    }
    detectApple();
  
  })()
  const GLOBAL_CONFIG = {
    root: '/',
    algolia: undefined,
    localSearch: undefined,
    translate: undefined,
    highlight: {
        "plugin": "highlight.js",
        "highlightCopy": true,
        "highlightLang": true,
        "highlightHeightLimit": false,
        "highlightFullpage": false,
        "highlightMacStyle": false
    },
    copy: {
        success: '复制成功',
        error: '复制失败',
        noSupport: '浏览器不支持'
    },
    relativeDate: {
        homepage: false,
        post: false
    },
    runtime: '',
    dateSuffix: {
        just: '刚刚',
        min: '分钟前',
        hour: '小时前',
        day: '天前',
        month: '个月前'
    },
    copyright: undefined,
    lightbox: 'null',
    Snackbar: undefined,
    infinitegrid: {
        js: 'https://cdn.jsdelivr.net/npm/@egjs/infinitegrid/dist/infinitegrid.min.js',
        buttonText: '加载更多'
    },
    isPhotoFigcaption: false,
    islazyloadPlugin: false,
    isAnchor: false,
    percent: {
        toc: true,
        rightside: false,
    },
    autoDarkmode: false
  }
  var GLOBAL_CONFIG_SITE = {
    title: '打包地',
    isHighlightShrink: false,
    isToc: false,
    pageType: 'home'
  }
  
  